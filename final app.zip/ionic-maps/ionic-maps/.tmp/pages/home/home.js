var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
export var HomePage = (function () {
    function HomePage(navCtrl) {
        this.navCtrl = navCtrl;
    }
    HomePage = __decorate([
        Component({
            selector: 'page-home',template:/*ion-inline-start:"C:\Users\lenovo\ionic-maps\ionic-maps\src\pages\home\home.html"*/'<ion-header>\n  <ion-navbar>\n\n    <ion-title>\n      <div id="appname">\n      Service Tracker App\n      </div>\n\n    </ion-title>\n  </ion-navbar>\n</ion-header>\n\n \n\n<ion-content> \n\n   \n              <div id="map-container">\n                <div id="input-div">\n                    <ion-item>\n                      <ion-label >Source</ion-label>\n                      <ion-input id="start"  data-onload =\'getSourceInputElement(this)\'></ion-input>\n                    </ion-item>\n\n                    <ion-item>\n                       <ion-label  >Destination</ion-label>\n                     <ion-input type="text" id="end" data-onload =\'getDestinationInputElement(this)\' > </ion-input>\n                    </ion-item>\n                 </div>\n                  <button ion-button onclick="getdir()" id="button">Start Tracking</button>\n                  <div id="map"> </div> \n                  <div id="menu"></div>\n               </div>   \n       \n     \n   \n\n</ion-content>               \n               \n\n\n'/*ion-inline-end:"C:\Users\lenovo\ionic-maps\ionic-maps\src\pages\home\home.html"*/
        }), 
        __metadata('design:paramtypes', [NavController])
    ], HomePage);
    return HomePage;
}());
//# sourceMappingURL=home.js.map